<template>
  <div class="overflow-auto container mt-5" align="center">
    <img class="noticeImage" alt="House Logo" src="../assets/notice.png" />
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.noticeImage {
  min-width: 300px;
  width: 650px;
  height: 150px;
  margin-right: 80px;
}
</style>
