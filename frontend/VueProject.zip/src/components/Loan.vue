<template lang="">
  <div style="background-color: #d7d7d7">
    <iframe
      width="1000px"
      height="2450px"
      style="position: absolute; top: -17px; z-index: -1"
      src="http://finlife.fss.or.kr/rentsubsidy/selectRentSubsidy.do?menuId=2000103"
      frameborder="0"
      scrolling="no"
    />
  </div>
</template>
<script>
export default {};
</script>
<style lang=""></style>
