<template>
  <div>
    <img class="mainImage" alt="House Logo" src="../assets/indeximage.png" />
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.mainImage {
  width: 100%;
  height: 350px;
  opacity: 0.7;
}
</style>
