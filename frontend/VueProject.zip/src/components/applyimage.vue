<template>
  <div class="overflow-auto container mt-5" align="center">
    <img class="applyImage" src="../assets/applyhome.png" align="center" />
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.applyImage {
  width: 80%;
  height: 80px;
}
</style>
